﻿using System;
using ClassLibrary4;
using System.Data.OleDb;

namespace ViewModel
{
    public class ReviewsDB : BaseDB
    {
        public ReviewList SelectAll()
        {
            command.CommandText = "SELECT * FROM Reviews";
            ReviewList list = new ReviewList(base.Select());
            return list;
        }

        public static Review SelectById(int id)
        {
            ReviewsDB db = new ReviewsDB();
            ReviewList list = db.SelectAll();
            return list.Find(item => item.Id == id);
        }

        public override BaseEntity NewEntity()
        {
            return new Review();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Review review = entity as Review;
            if (review != null)
            {
                if (reader["Rating"] != DBNull.Value)
                    review.Rating = Convert.ToInt32(reader["Rating"]);

                if (reader["CommentText"] != DBNull.Value)
                    review.CommentText = reader["CommentText"].ToString();

                if (reader["ReviewDate"] != DBNull.Value)
                    review.ReviewDate = Convert.ToDateTime(reader["ReviewDate"]);

                if (reader["CookID"] != DBNull.Value)
                {
                    int cookId = Convert.ToInt32(reader["CookID"]);
                    review.Cook = CooksDB.SelectById(cookId);
                }

                if (reader["RecipeID"] != DBNull.Value)
                {
                    int recipeId = Convert.ToInt32(reader["RecipeID"]);
                    review.Recipe = RecipesDB.SelectById(recipeId);
                }
            }
            base.CreateModel(entity);
            return entity;
        }

        protected override void CreateInsertedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Review review = entity as Review;
            if (review != null)
            {
                string sqlStr = "INSERT INTO Reviews (Rating, CommentText, ReviewDate, CookID, RecipeID) VALUES (@rating, @comment, @rDate, @cookId, @recipeId)";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@rating", review.Rating));
                cmd.Parameters.Add(new OleDbParameter("@comment", review.CommentText ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@rDate", review.ReviewDate));
                cmd.Parameters.Add(new OleDbParameter("@cookId", review.Cook != null ? (object)review.Cook.Id : DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@recipeId", review.Recipe != null ? (object)review.Recipe.Id : DBNull.Value));
            }
        }

        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Review review = entity as Review;
            if (review != null)
            {
                string sqlStr = "UPDATE Reviews SET Rating = @rating, CommentText = @comment, ReviewDate = @rDate, CookID = @cookId, RecipeID = @recipeId WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@rating", review.Rating));
                cmd.Parameters.Add(new OleDbParameter("@comment", review.CommentText ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@rDate", review.ReviewDate));
                cmd.Parameters.Add(new OleDbParameter("@cookId", review.Cook != null ? (object)review.Cook.Id : DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@recipeId", review.Recipe != null ? (object)review.Recipe.Id : DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@id", review.Id));
            }
        }

        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Review review = entity as Review;
            if (review != null)
            {
                string sqlStr = "DELETE FROM Reviews WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@id", review.Id));
            }
        }
    }
}