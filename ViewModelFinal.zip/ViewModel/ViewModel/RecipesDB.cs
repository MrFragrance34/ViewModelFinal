﻿using System;
using ClassLibrary4;
using System.Data.OleDb;

namespace ViewModel
{
    public class RecipesDB : BaseDB
    {
        public RecipeList SelectAll()
        {
            command.CommandText = "SELECT * FROM Recipes";
            RecipeList list = new RecipeList(base.Select());
            return list;
        }

        public static Recipe SelectById(int id)
        {
            RecipesDB db = new RecipesDB();
            RecipeList list = db.SelectAll();
            return list.Find(item => item.Id == id);
        }

        public override BaseEntity NewEntity()
        {
            return new Recipe();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Recipe recipe = entity as Recipe;
            if (recipe != null)
            {
                recipe.Title = reader["Title"].ToString();
                recipe.Description = reader["Description"].ToString();
                recipe.Instructions = reader["Instructions"].ToString();

                if (reader["PrepTimeMins"] != DBNull.Value)
                    recipe.PrepTimeMins = Convert.ToInt32(reader["PrepTimeMins"]);

                if (reader["ImagePath"] != DBNull.Value)
                    recipe.ImagePath = reader["ImagePath"].ToString();

                if (reader["RecipeDate"] != DBNull.Value)
                    recipe.RecipeDate = Convert.ToDateTime(reader["RecipeDate"]);

                if (reader["CookID"] != DBNull.Value)
                {
                    int cookId = Convert.ToInt32(reader["CookID"]);
                    recipe.Cook = CooksDB.SelectById(cookId);
                }
            }
            base.CreateModel(entity);
            return entity;
        }

        protected override void CreateInsertedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Recipe recipe = entity as Recipe;
            if (recipe != null)
            {
                string sqlStr = "INSERT INTO Recipes (Title, Description, Instructions, PrepTimeMins, ImagePath, RecipeDate, CookID) VALUES (@title, @desc, @inst, @prep, @img, @rDate, @cookId)";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@title", recipe.Title ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@desc", recipe.Description ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@inst", recipe.Instructions ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@prep", recipe.PrepTimeMins));
                cmd.Parameters.Add(new OleDbParameter("@img", recipe.ImagePath ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@rDate", recipe.RecipeDate));
                cmd.Parameters.Add(new OleDbParameter("@cookId", recipe.Cook != null ? (object)recipe.Cook.Id : DBNull.Value));
            }
        }

        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Recipe recipe = entity as Recipe;
            if (recipe != null)
            {
                string sqlStr = "UPDATE Recipes SET Title = @title, Description = @desc, Instructions = @inst, PrepTimeMins = @prep, ImagePath = @img, RecipeDate = @rDate, CookID = @cookId WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@title", recipe.Title ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@desc", recipe.Description ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@inst", recipe.Instructions ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@prep", recipe.PrepTimeMins));
                cmd.Parameters.Add(new OleDbParameter("@img", recipe.ImagePath ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@rDate", recipe.RecipeDate));
                cmd.Parameters.Add(new OleDbParameter("@cookId", recipe.Cook != null ? (object)recipe.Cook.Id : DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@id", recipe.Id));
            }
        }

        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Recipe recipe = entity as Recipe;
            if (recipe != null)
            {
                string sqlStr = "DELETE FROM Recipes WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@id", recipe.Id));
            }
        }
    }
}