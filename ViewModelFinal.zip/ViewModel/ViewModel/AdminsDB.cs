﻿using System;
using ClassLibrary4;
using System.Data.OleDb;

namespace ViewModel
{
    public class AdminsDB : BaseDB
    {
        public AdminList SelectAll()
        {
            command.CommandText = "SELECT * FROM Admins";
            AdminList list = new AdminList(base.Select());
            return list;
        }

        public override BaseEntity NewEntity()
        {
            return new Admin();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Admin admin = entity as Admin;
            if (admin != null)
            {
                if (reader["AdminRole"] != DBNull.Value)
                    admin.AdminRole = reader["AdminRole"].ToString();
            }
            base.CreateModel(entity);
            return entity;
        }

        protected override void CreateInsertedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Admin admin = entity as Admin;
            if (admin != null)
            {
                string sqlStr = "INSERT INTO Admins (AdminRole) VALUES (@role)";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@role", admin.AdminRole ?? (object)DBNull.Value));
            }
        }

        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Admin admin = entity as Admin;
            if (admin != null)
            {
                string sqlStr = "UPDATE Admins SET AdminRole = @role WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@role", admin.AdminRole ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@id", admin.Id));
            }
        }

        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Admin admin = entity as Admin;
            if (admin != null)
            {
                string sqlStr = "DELETE FROM Admins WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@id", admin.Id));
            }
        }
    }
}