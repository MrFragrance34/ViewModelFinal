﻿using System;
using ClassLibrary4;
using System.Data.OleDb;

namespace ViewModel
{
    public class CooksDB : BaseDB
    {
        public CookList SelectAll()
        {
            command.CommandText = "SELECT * FROM Cooks";
            CookList list = new CookList(base.Select());
            return list;
        }

        public static Cook SelectById(int id)
        {
            CooksDB db = new CooksDB();
            CookList list = db.SelectAll();
            return list.Find(item => item.Id == id);
        }

        public override BaseEntity NewEntity()
        {
            return new Cook();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Cook cook = entity as Cook;
            if (cook != null)
            {
                cook.Bio = reader["Bio"].ToString();
                if (reader["ProfilePicPath"] != DBNull.Value)
                    cook.ProfilePicPath = reader["ProfilePicPath"].ToString();
            }
            base.CreateModel(entity);
            return entity;
        }

        protected override void CreateInsertedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Cook cook = entity as Cook;
            if (cook != null)
            {
                // מציאת ה-ID הגבוה ביותר בטבלה והוספת 1 (עקב היעדר AutoNumber במסד)
                CooksDB db = new CooksDB();
                CookList list = db.SelectAll();
                int maxId = 0;
                foreach (Cook c in list)
                {
                    if (c.Id > maxId)
                        maxId = c.Id;
                }
                cook.Id = maxId + 1;

                string sqlStr = "INSERT INTO Cooks (ID, Bio, ProfilePicPath) VALUES (@id, @bio, @pic)";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@id", cook.Id));
                cmd.Parameters.Add(new OleDbParameter("@bio", cook.Bio ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@pic", cook.ProfilePicPath ?? (object)DBNull.Value));
            }
        }

        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Cook cook = entity as Cook;
            if (cook != null)
            {
                string sqlStr = "UPDATE Cooks SET Bio = @bio, ProfilePicPath = @pic WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@bio", cook.Bio ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@pic", cook.ProfilePicPath ?? (object)DBNull.Value));
                cmd.Parameters.Add(new OleDbParameter("@id", cook.Id));
            }
        }

        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Cook cook = entity as Cook;
            if (cook != null)
            {
                string sqlStr = "DELETE FROM Cooks WHERE ID = @id";
                cmd.CommandText = sqlStr;
                cmd.Parameters.Add(new OleDbParameter("@id", cook.Id));
            }
        }
    }
}