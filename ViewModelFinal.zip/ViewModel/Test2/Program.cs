﻿using System;
using ClassLibrary4;
using ViewModel;

namespace Test2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("=== בדיקת מתכונים (כולל תאריך ומפתח זר) ===");
                RecipesDB recipesDB = new RecipesDB();
                RecipeList recipes = recipesDB.SelectAll();

                foreach (Recipe recipe in recipes)
                {
                    Console.WriteLine($"ID: {recipe.Id} | כותרת: {recipe.Title} | תאריך: {recipe.RecipeDate:dd/MM/yyyy}");
                    if (recipe.Cook != null)
                    {
                        Console.WriteLine($"    טבח: {recipe.Cook.Bio}");
                    }
                    Console.WriteLine(new string('-', 40));
                }

                Console.WriteLine("\n=== בדיקת ביקורות (כולל תאריך ומפתחות זרים) ===");
                ReviewsDB reviewsDB = new ReviewsDB();
                ReviewList reviews = reviewsDB.SelectAll();

                foreach (Review review in reviews)
                {
                    Console.WriteLine($"ID: {review.Id} | דירוג: {review.Rating}/5 | תאריך: {review.ReviewDate:dd/MM/yyyy}");
                    Console.WriteLine($"    תוכן: {review.CommentText}");
                    if (review.Cook != null)
                    {
                        Console.WriteLine($"    טבח כותב: {review.Cook.Bio}");
                    }
                    if (review.Recipe != null)
                    {
                        Console.WriteLine($"    מתכון: {review.Recipe.Title}");
                    }
                    Console.WriteLine(new string('-', 40));
                }

                // === בדיקת הוספה (Insert) ושמירה במסד הנתונים ===
                Console.WriteLine("\n=== בדיקת הוספת טבח חדש (Insert) ===");
                CooksDB cooksDB = new CooksDB();
                Cook newCook = new Cook()
                {
                    Bio = "שף מומחה למאכלים מזרחיים",
                    ProfilePicPath = "chef_new.jpg"
                };

                cooksDB.Insert(newCook);
                int rowsInserted = cooksDB.SaveChanges();
                Console.WriteLine($"{rowsInserted} rows inserted successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"שגיאה בהרצה: {ex.Message}");
            }

            Console.WriteLine("\nלחץ על מקש כלשהו לסיום...");
            Console.ReadKey();
        }
    }
}